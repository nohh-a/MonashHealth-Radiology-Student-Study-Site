<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Users Model
 *
 * @method \App\Model\Entity\User newEmptyEntity()
 * @method \App\Model\Entity\User newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\User[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\User get($primaryKey, $options = [])
 * @method \App\Model\Entity\User findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\User patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\User[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\User|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class UsersTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('users');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('username')
            ->requirePresence('username', 'create')
            ->notEmptyString('username');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmptyString('email');

        $validator
            ->scalar('password')
            ->maxLength('password', 96)
            ->requirePresence('password', 'create')
            ->notEmptyString('password')
            ->add('password', 'custom', [
                'rule' => function ($value, $context) {
                    //Write custom validation rules here
                    // Check if the password length is at least 6 characters
                    // Check whether it contains uppercase and lowercase letters, numbers and special symbols
                    $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!])[A-Za-z\d@#$%^&+=!]{6,}$/';
                    return (bool)preg_match($regex, $value);
                },
                'message' => 'Password must contain at least 6 characters, including uppercase and lowercase letters, numbers and special symbols'
            ]);

        // Validate retyped password
        $validator
            ->requirePresence('password_confirm', 'create')
            ->sameAs('password_confirm', 'password', 'Both passwords must match');

        $validator
            ->scalar('first_name')
            ->maxLength('first_name', 128)
            ->requirePresence('first_name', 'create')
            ->notEmptyString('first_name');

        $validator
            ->scalar('last_name')
            ->maxLength('last_name', 128)
            ->requirePresence('last_name', 'create')
            ->notEmptyString('last_name');

        $validator
            ->scalar('access_role')
            ->notEmptyString('access_role');

        $validator
            ->scalar('contributor')
            ->notEmptyString('contributor');

        $validator
            ->scalar('avatar')
            ->allowEmptyString('avatar');

        $validator
            ->scalar('nonce')
            ->maxLength('nonce', 128)
            ->allowEmptyString('nonce');

        $validator
            ->dateTime('nonce_expiry')
            ->allowEmptyDateTime('nonce_expiry');

        return $validator;
    }

    public function validationResetPassword(Validator $validator): Validator {
        $validator
            ->scalar('password')
            ->maxLength('password', 96)
            ->requirePresence('password')
            ->notEmptyString('password')
            ->add('password', 'custom', [
                'rule' => function ($value, $context) {
                    //Write custom validation rules here
                    // Check if the password length is at least 6 characters
                    // Check whether it contains uppercase and lowercase letters, numbers and special symbols
                    $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!])[A-Za-z\d@#$%^&+=!]{6,}$/';
                    return (bool)preg_match($regex, $value);
                },
                'message' => 'Password must contain at least 6 characters, including uppercase and lowercase letters, numbers and special symbols'
            ]);

        // Validate retyped password
        $validator
            ->requirePresence('password_confirm', 'reset-password')
            ->sameAs('password_confirm', 'password', 'Both passwords must match');

        $validator
            ->uuid('nonce')
            ->maxLength('nonce', 128)
            ->allowEmptyString('nonce');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->isUnique(['username']), ['errorField' => 'username']);
        $rules->add($rules->isUnique(['email']), ['errorField' => 'email']);

        return $rules;
    }
}
