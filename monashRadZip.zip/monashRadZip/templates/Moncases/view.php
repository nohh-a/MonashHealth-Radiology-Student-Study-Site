<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.10.0
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */

/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Moncase $moncase
 */

$this->assign('title', 'View Case - Cases');
?>

<head>
<style>
    li h6 {
        color: #576ec2;
    }
    li {
        padding: 12px;
    }
    body {
        font-size: 15px;
    }

    .side-btn {
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .page-title .content-box .bread-crumb li:before {
        top: 12px;
    }

   .pricing-block-one .pricing-table .table-content ul li {
        background: #f3f8ff; border-radius: 15px;

    }

</style>
</head>

<!--Page Title-->
<section class="page-title bg-color-1 text-center">
    <div class="auto-container">
        <div class="sec-title" style="margin-bottom: 0px;">
            <p><?= h($moncase->case_type) ?> CASE </p>
        </div>
        <div class="content-box">
            <h1><?= h($moncase->diagnosis) ?></h1>
            <ul class="bread-crumb clearfix">
                <li><a href="<?= $this->Url->build(['controller' => 'moncases', 'action' => 'userlist'])?>">Case List</a></li>
                <li>View Case: <?= h($moncase->diagnosis) ?></li>
            </ul>
        </div>

    </div>
</section>
<!--End Page Title-->


<?= $this->Flash->render() ?>
<!-- portfolio-details -->
<section class="portfolio-details sec-pad">
    <div class="auto-container">
        <div class="inner-container">
            <div class="row">

                <div class="col-md-8">
                    <button class="btn btn-outline-primary" onclick="goBack()">
                        <?= $this->Html->tag('i', '  ', ['class' => 'fas fa-arrow-left']) ?>
                    </button>

                    <td>
                        <button onclick="copyTextAndRedirect()" class='btn btn-outline-primary'>
                            Copy Accession No
                        </button>
                    </td>

                    <td>
                        <a class="btn btn-outline-primary" href="JavaScript:newPostDICOM('https://www.postdicom.com/en/login');">
                            PostDICOM
                        </a>
                    </td>
                </div>

                <br><br>

                <div class="col-lg-8">
                        <figure class="image-box">
                            <a>
                                <img src="<?= $this->Url->image($moncase->image_url, ['style' => 'max-width:50%; max-height:50%;', 'alt' => 'photo']) ?>" onclick="copyTextAndRedirect()">
                            </a>
                        </figure>
                 </div>

                <div class="col-lg-4">
                    <div class="widget-content" style="display: flex; justify-content: space-around; align-items: center;text-align: center;">

                        <div class="col-lg-4" >
<!--                            --><?php //=
//                            $this->Form->postLink(__('Favorite'),
//                                ['action' => 'savecaseaction', $moncase->id],
//                                ['class' => 'theme-btn style-one',
//                                    'confirm' => __('Are you sure you want to save # {0}?', $moncase->diagnosis)])
//                            ?>

                            <!--                            if the user do not have any folder, collect button going to crete a folder-->
                            <!--                            -->
                            <!--                            else, going to add the case into a folder.-->
                            <?php if ($collectionCount == 0): ?>
                                <?=
                                $this->Html->link(
                                    $this->Html->tag('i', '', ['class' => 'fas fa-regular fa-bookmark']),
                                    [
                                        'controller' => 'collections',
                                        'action' => 'create_collection',
                                        $moncase->id
                                    ],
                                    [
                                        'class' => 'theme-btn style-two',
                                        'escape' => false
                                    ]
                                )
                                ?>

                            <?php else: ?>

                                <?=
                                $this->Html->link(
                                    $this->Html->tag('i', '', ['class' => 'fas fa-regular fa-bookmark']),
                                    [
                                        'controller' => 'collections',
                                        'action' => 'select_folder',
                                        $moncase->id
                                    ],
                                    [
                                        'class' => 'theme-btn style-two',
                                        'escape' => false
                                    ]
                                )
                                ?>


                            <?php endif; ?>

                        </div>

                        <div class="col-lg-4">
                            <?=
                            $this->Html->link(
                                $this->Html->tag('i', '', ['class' => 'fas fa-regular fa-edit']),
                                ['action' => 'edit', $moncase->id],
                                [
                                    'class' => 'theme-btn style-one',
                                    'escape' => false
                                ]
                            )
                            ?>
                        </div>
                    </div>


                <section class="accordion-box" style="padding: 0px 0px 0px 0px;">
                    <div class="accordion block active-block">
                        <div class="acc-btn active">
                            <h4><span>+</span> Case Details</h4>
                        </div>
                        <div class="acc-content current">
                        <ul class="content">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <li><h6>Accession No: </h6> <?= !empty($moncase->accession_no) ? h($moncase->accession_no) : 'N/A' ?></li>
                                    <li><h6>Specialty: </h6> <?= !empty($moncase->specialty) ? h($moncase->specialty) : 'N/A' ?></li>
                                    <li><h6>Seen By: </h6> <?= !empty($moncase->seen_by) ? h($moncase->seen_by) : 'N/A' ?></li>
                                    <li><h6>Tags: </h6> <?= !empty($moncase->tags) ? h($moncase->tags) : 'N/A' ?></li>
                                    <li><h6>Date: </h6> <?= !empty($moncase->date) ? h($moncase->date) : 'N/A' ?></li>
                                </div>

                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <li><h6>Marks: </h6> <?= !empty($moncase->max_marks) ? h($moncase->max_marks) : 'N/A' ?></li>
                                    <li><h6>Case Rating:</h6><?= !empty($moncase->rating) ? h($moncase->rating) : 'N/A' ?></li>
                                    <li><h6>Author: </h6> <?= !empty($moncase->author) ? h($moncase->author) : 'N/A' ?></li>
                                    <li><h6>Contributor: </h6> <?= !empty($moncase->contributor) ? h($moncase->contributor) : 'N/A' ?></li>
                                </div>
                            </div>


                        </ul>
                        </div>
                   </div>

                </section>

                </div>

            </div>

            <section class="pricing-section bg-color-1 sec-pad">
                <div class="auto-container">
                    <div class="tabs-box">
                        <div class="upper-box clearfix">
                            <div class="tab-btn-box pull-right">
                                <ul class="tab-btns tab-buttons clearfix">
                                    <li class="tab-btn active-btn" data-tab="#tab-1">General</li>
                                    <li class="tab-btn" data-tab="#tab-2">Other</li>
                                </ul>
                            </div>
                        </div>
                        <div class="tabs-content">
                            <div class="tab active-tab" id="tab-1">
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12 col-sm-12 pricing-block">
                                        <div class="pricing-block-one">
                                            <div class="pricing-table">
                                                <div class="table-content">
                                                    <ul>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                                <h3>Differential Diagnosis </h3>
                                                                <li><?= !empty($moncase->differential_diagnosis) ? h($moncase->differential_diagnosis) : 'N/A' ?></li>
                                                                <h3>History </h3>
                                                                <li><?= !empty($moncase->history) ? h($moncase->history) : 'N/A' ?></li>
                                                                <h3>Findings </h3>
                                                                <li><?= !empty($moncase->findings) ? h($moncase->findings) : 'N/A' ?></li>
                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                                <h3>Imaging</h3>
                                                                <li><?= !empty($moncase->imaging) ? h($moncase->imaging) : 'N/A' ?></li>
                                                                <h3>Teaching Points</h3>
                                                                <li><?= !empty($moncase->teaching_points) ? h($moncase->teaching_points) : 'N/A' ?></li>
                                                            </div>
                                                        </div>

                                                    </ul>
                                                </div>
                                                <div class="table-footer" style="padding-top:30px;">
                                                    <div class="row d-flex justify-content-center">

                                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $moncase->id], ['class' => 'theme-btn style-two']) ?>
                                                        </div>
                                                        <br><br>

                                                        <div class="col-lg-4 col-md-6 col-sm-12">
<!--                                                            --><?php //= $this->Form->postLink(__('Favorite'), ['action' => 'savecaseaction', $moncase->id], ['class' => 'theme-btn style-two', 'confirm' => __('Are you sure you want to save # {0}?', $moncase->diagnosis)]) ?>
                                                            <?php if ($collectionCount == 0): ?>
                                                                <?=
                                                                $this->Html->link(__('Favourite'),
                                                                    [
                                                                        'controller' => 'collections',
                                                                        'action' => 'create_collection',
                                                                        $moncase->id
                                                                    ],
                                                                    [
                                                                        'class' => 'theme-btn style-two'
                                                                    ]
                                                                )
                                                                ?>

                                                            <?php else: ?>
                                                                <?=
                                                                $this->Html->link(__('Favourite'),
                                                                    [
                                                                        'controller' => 'collections',
                                                                        'action' => 'select_folder',
                                                                        $moncase->id
                                                                    ],
                                                                    [
                                                                        'class' => 'theme-btn style-two'
                                                                    ]
                                                                )
                                                                ?>

                                                            <?php endif; ?>
                                                        </div>
                                                        <br><br>

                                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                                            <?= $this->Form->postLink(__('Archive'), ['action' => 'changecasestatus', $moncase->id], ['class' => 'theme-btn style-one', 'confirm' => __('Are you sure you want to archive # {0}?', $moncase->diagnosis)]) ?>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab" id="tab-2">
                                <div class="row clearfix">
                                    <div class="col-lg-12 col-md-12 col-sm-12 pricing-block">
                                        <div class="pricing-block-one">
                                            <div class="pricing-table">
                                                <div class="table-content">
                                                    <ul>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                                <h3>Further Investigation </h3>
                                                                <li><?= !empty($moncase->further_investigation) ? h($moncase->further_investigation) : 'N/A' ?></li>
                                                                <h3>Management</h3>
                                                                <li><?= !empty($moncase->management) ? h($moncase->management) : 'N/A' ?></li>
                                                                <h3>Anatomy</h3>
                                                                <li><?= !empty($moncase->anatomy) ? h($moncase->anatomy) : 'N/A' ?></li>
                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                                <h3>Pathology</h3>
                                                                <li><?= !empty($moncase->pathology) ? h($moncase->pathology) : 'N/A' ?></li>
                                                                <h3>Safety</h3>
                                                                <li><?= !empty($moncase->safety) ? h($moncase->safety) : 'N/A' ?></li>
                                                                <h3>Intrinsic Roles</h3>
                                                                <li><?= !empty($moncase->intrinsic_roles) ? h($moncase->intrinsic_roles) : 'N/A' ?></li>
                                                            </div>
                                                        </div>

                                                    </ul>
                                                </div>
                                                <div class="table-footer" style="padding-top:30px;">
                                                    <div class="row d-flex justify-content-center">

                                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $moncase->id], ['class' => 'theme-btn style-two']) ?>
                                                        </div>
                                                        <br><br>

                                                        <div class="col-lg-4 col-md-6 col-sm-12">
                                                            <!--                                                            --><?php //= $this->Form->postLink(__('Favorite'), ['action' => 'savecaseaction', $moncase->id], ['class' => 'theme-btn style-two', 'confirm' => __('Are you sure you want to save # {0}?', $moncase->diagnosis)]) ?>
                                                            <?php if ($collectionCount == 0): ?>
                                                                <?=
                                                                $this->Html->link(__('Favourite'),
                                                                    [
                                                                        'controller' => 'collections',
                                                                        'action' => 'create_collection',
                                                                        $moncase->id
                                                                    ],
                                                                    [
                                                                        'class' => 'theme-btn style-two'
                                                                    ]
                                                                )
                                                                ?>

                                                            <?php else: ?>
                                                                <?=
                                                                $this->Html->link(__('Favourite'),
                                                                    [
                                                                        'controller' => 'collections',
                                                                        'action' => 'select_folder',
                                                                        $moncase->id
                                                                    ],
                                                                    [
                                                                        'class' => 'theme-btn style-two'
                                                                    ]
                                                                )
                                                                ?>

                                                            <?php endif; ?>
                                                        </div>
                                                        <br><br>

                                                        <div class="col-lg-4 col-md-12 col-sm-12">
                                                            <?= $this->Form->postLink(__('Archive'), ['action' => 'changecasestatus', $moncase->id], ['class' => 'theme-btn style-one', 'confirm' => __('Are you sure you want to archive # {0}?', $moncase->diagnosis)]) ?>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>

<script>
    function goBack() {
        window.history.back();
    }

    /* Copy accession_no to clipboard and Jump to link*/
    function copyTextAndRedirect() {

        navigator.clipboard.writeText("<?= h($moncase->accession_no) ?>").then(function() {
            // Copied successfully
            alert("Successfully copied to clipboard: " + "<?= h($moncase->accession_no) ?>");

            // Jump to link
            window.location.href = "https://monashimaging.monashhealth.org/portal/Login.aspx";
        }).catch(function(err) {
            console.error("Error copying to clipboard: " + err);
        });
    }

    /* Copy accession_no to clipboard */
    function copyText() {
        navigator.clipboard.writeText("<?= h($moncase->accession_no) ?>").then(function() {
            alert("Successfully copied to clipboard: " + "<?= h($moncase->accession_no) ?>");
        }).catch(function(err) {
            console.error("Error copying to clipboard: " + err);
        });
    }

    /* new pop windows for PostDICOM */
    function newPostDICOM(url) {
        navigator.clipboard.writeText("<?= h($moncase->accession_no) ?>").then(function() {
            alert("Successfully copied to clipboard: " + "<?= h($moncase->accession_no) ?>");
        }).catch(function(err) {
            console.error("Error copying to clipboard: " + err);
        });

        popupPostDICOM = window.open(url,'popupPostDICOM','height=600,width=1000,left=200,top=60,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes');
    }

</script>
