<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.10.0
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */

/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Moncase> $moncases
 * @var int $oscerCount
 * @var int $longCount
 * @var int $mediumCount
 * @var int $shortCount
 * @var int $generalCount
 */

$this->assign('title', 'Case List - Cases');
?>

<head>
    <style>
        .image-box p {
            color: #ffffff;
            font-weight: 530;
            text-align: left;
            padding: 5px;
        }

        .designation {
            color: #576ec2;
            padding-bottom: 5px;

        }

        .project-block-one .inner-box .image-box {
            background: #576ec2;

        }

        .carousel-text h5 {
            padding-top: 10px;
            padding-bottom: 5px;
            color: #576ec2;
            font-weight: 600;
            font-size: 18px;
        }

        .carousel-text p {
            padding-bottom: 30px;
            font-family: 'Poppins', sans-serif;

        }

        .button a {
            color: #6377ee !important;

        }

        .content p {
            margin-left: 25px;
        }

        .noresults {
            padding-left: 30px;
        }
        .sidebar-page-container .sidebar {
            margin-left: 5px;
        }

    </style>


</head>

<!--Page Title-->
<section class="page-title bg-color-1 text-center">
    <div class="auto-container">
        <div class="content-box">
            <h1>Case Lists</h1>
            <ul class="bread-crumb clearfix">
                <button class="toggle-view-button theme-btn style-one" data-view="grid">Grid</button>
                <button class="toggle-view-button theme-btn style-two" data-view="list">List</button>
            </ul>
        </div>
    </div>
</section>
<!--End Page Title-->
<?= $this->Flash->render() ?>

<!-- blog-grid -->
<section class="sidebar-page-container blog-grid">
    <div class="auto-container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class = "row">
                    <!-- Sort Feature -->
                    <div class ="mon-sort col-lg-8 col-md-8 col-sm-8 col-8">
                        <h3> Sort by</h3>
                        <?= $this->Form->create(null, ['url' => ['controller' => 'Moncases', 'action' => 'userlistNotadmin'], 'type' => 'get']) ?>
                        <?= $this->Form->select(
                            'sort',
                            [
                                'newest' => ' Newest - Oldest',
                                'oldest' => 'Oldest - Newest',
                                'az' => 'A-Z',
                                'za' => 'Z-A',
                                'rating_asc' => 'Rating ASC',
                                'rating_desc' => 'Rating DESC',
                            ],
                            [
                                'empty' => false,
                                'default' => $this->request->getQuery('sort'),
                                'class' => 'custom-select',
                            ]
                        ) ?>


                        <?= $this->Form->button(__('Apply'), ['class' => 'btn btn-secondary', 'style' => 'margin-top: -20px;']) ?>

                    </div>

                    <!-- Add New Case Btn 1 Start -->
                    <div class ="mon-new-btn-phone col-lg-1 col-md-1 col-sm-1 col-1">
                        <h3><br></h3>
                        <?= $this->Html->link(__('New'), ['controller' => 'moncases', 'action' => 'addnewcase'], ['class' => 'theme-btn style-one btn-phone']) ?>
                    </div>
                    <!-- Add New Case Btn 1 Start -->

                    <!-- Mobile Filters Start -->
                    <div class ="mon-modal col-lg-2 col-md-1 col-sm-2 col-2">
                        <!-- Trigger the Mobile with a button -->
                        <i class="fas fas fa-search fa-lg modal-hide" data-toggle="modal" data-target="#myModal"></i>
                        <!-- Mobile -->
                        <div id="myModal" class="modal fade" role="dialog">
                            <div class="modal-dialog">
                                <!-- Mobile content-->
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div class="sidebar">

                                            <!-- Search Start -->
                                            <div class="sidebar-widget sidebar-search">
                                                <div class="widget-title">
                                                    <h3>Search</h3>
                                                </div>
                                                <div class="widget-content">
                                                    <div class="form-group">
                                                        <?= $this->Form->input('search_mobile', [
                                                            'type' => 'search',
                                                            'placeholder' => 'Search',
                                                            'default' => $this->request->getQuery('search_mobile'),
                                                        ]) ?>
                                                        <button type="submit" class="search-button">
                                                            <?= $this->Html->tag('i', '', ['class' => 'fas fa-search']) ?>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Search End -->

                                            <!-- Filter variables Start -->
                                            <div class="sidebar-widget sidebar-categories">
                                                <div class="widget-title">
                                                    <h3>FILTERS</h3>
                                                </div>
                                                <div class="widget-content">
                                                    <ul class="accordion-box">
                                                        <li class="accordion block active-block">
                                                            <div class="acc-btn active">
                                                                <h4><span>+</span> Type</h4>
                                                            </div>
                                                            <div class="acc-content current">
                                                                <div class="content">
                                                                    <p>
                                                                        <?= $this->Form->select('case_type_mobile', [
                                                                            'Oscer' => '  Oscer',
                                                                            'Long' => '  Long',
                                                                            'Medium' => '  Medium',
                                                                            'Short' => '  Short',
                                                                            'General' => '  General',
                                                                        ], [
                                                                            'class' => 'select select_mod-a jelect',
                                                                            'default' => $this->request->getQuery('case_type_mobile'),
                                                                            'empty' => 'Choose Case Type',
                                                                            'multiple' => 'checkbox',
                                                                        ]); ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="accordion block active-block">
                                                            <div class="acc-btn">
                                                                <h4><span>+</span>Contributor</h4>
                                                            </div>
                                                            <div class="acc-content">
                                                                <div class="content">
                                                                    <p>
                                                                        <?= $this->Form->select('contributor_mobile', [
                                                                            'Trainee' => '  Trainee',
                                                                            'Consultant' => '  Consultant',
                                                                            'Library' => '  Library',
                                                                        ], [
                                                                            'class' => 'select select_mod-a jelect',
                                                                            'default' => $this->request->getQuery('contributor_mobile'),
                                                                            'empty' => 'Choose Contributor',
                                                                            'multiple' => 'checkbox',
                                                                        ]); ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="accordion block active-block">
                                                            <div class="acc-btn">
                                                                <h4><span>+</span>Rating</h4>
                                                            </div>
                                                            <div class="acc-content">
                                                                <div class="content">
                                                                    <p>
                                                                        <?= $this->Form->select('rating_mobile', [
                                                                            '1' => '  1',
                                                                            '2' => '  2',
                                                                            '3' => '  3',
                                                                            '4' => '  4',
                                                                            '5' => '  5',
                                                                        ], [
                                                                            'class' => 'form-select',
                                                                            'default' => $this->request->getQuery('rating_mobile'),
                                                                            'empty' => 'Choose Rating',
                                                                            'multiple' => 'checkbox',
                                                                            'id' => 'form-select',
                                                                        ]); ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="accordion block active-block">
                                                            <div class="acc-btn">
                                                                <h4><span>+</span>Specialty</h4>
                                                            </div>
                                                            <div class="acc-content">
                                                                <div class="content">
                                                                    <p>
                                                                        <?= $this->Form->select('specialty_mobile', [
                                                                            'ABDOMINAL' => '  ABDOMINAL',
                                                                            'CARDIOTHORACIC' => '  CARDIOTHORACIC',
                                                                            'NEURO' => '  NEURO',
                                                                            'HEAD AND NECK' => '  HEAD AND NECK',
                                                                            'MSK' => '  MSK',
                                                                            'BREAST' => '  BREAST',
                                                                            'GYN' => '  GYN',
                                                                            'O+G' => '  O+G',
                                                                            'PEADS' => '  PEADS',
                                                                            'VASCULAR' => '  VASCULAR',
                                                                            'INTERVENTION' => '  INTERVENTION',
                                                                        ], [
                                                                            'class' => 'form-select',
                                                                            'default' => $this->request->getQuery('specialty_mobile'),
                                                                            'empty' => 'Choose Specialty',
                                                                            'multiple' => 'checkbox',
                                                                        ]); ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </li>
                                                        <li class="accordion block active-block">
                                                            <div class="acc-btn">
                                                                <h4><span>+</span>Imaging</h4>
                                                            </div>
                                                            <div class="acc-content">
                                                                <div class="content">
                                                                    <p>
                                                                        <?= $this->Form->select('imaging_mobile', [
                                                                            'X-ray' => '  X-ray',
                                                                            'Ultrasound' => '  Ultrasound',
                                                                            'CT' => '  CT',
                                                                            'MRI' => '  MRI',
                                                                            'Nuclear Medicine' => '  Nuclear Medicine',
                                                                            'Fluoroscopy' => '  Fluoroscopy',
                                                                            'Mammography' => '  Mammography',
                                                                            'Other' => '  Other',
                                                                        ], [
                                                                            'class' => 'form-select',
                                                                            'default' => $this->request->getQuery('imaging_mobile'),
                                                                            'empty' => 'Select Imaging',
                                                                            'multiple' => 'checkbox',
                                                                        ]) ?>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- Filter variables End -->

                                            <div class="sidebar-widget sidebar-tags">
                                                <div class="widget-title">
                                                    <div class="widget-content" style="display: flex; justify-content: space-around; align-items: center;">
                                                        <?= $this->Form->button(__('Apply Filter'), ['class' => 'theme-btn style-one', 'style' => 'margin-right: 10px;']) ?>
                                                        <a href="<?= $this->Url->build('/') ?>"><button class="theme-btn style-two" style="flex: 1;">Reset Filter</button></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Mobile Filters End -->

                    <!-- Add New Case Btn 2 Start -->
                    <div class ="mon-new-btn-desk col-lg-1 col-md-1 col-sm-1 col-1">
                        <h3><br></h3>
                        <?= $this->Html->link(__('New'), ['controller' => 'moncases', 'action' => 'addnewcase'], ['class' => 'theme-btn style-one btn-desk']) ?>
                    </div>
                    <!-- Add New Case Btn 2 Start -->

                </div>
            </div>
        </div>
        <!-- default content-->
        <div class="row clearfix">
            <!-- grid view-->
            <div class="col-lg-3 col-md-12 col-sm-12 sidebar-side sidebar-hide">
                <div class="sidebar">

                    <!-- Search Start -->
                    <div class="sidebar-widget sidebar-search">
                        <div class="widget-title">
                            <h3>Search</h3>
                        </div>
                        <div class="widget-content">
                            <div class="form-group">
                                <?= $this->Form->input('search', [
                                    'type' => 'search',
                                    'placeholder' => 'Search',
                                    'default' => $this->request->getQuery('search'),
                                ]) ?>
                                <button type="submit" class="search-button">
                                    <?= $this->Html->tag('i', '', ['class' => 'fas fa-search']) ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- Search End -->

                    <!-- Filter variables Start -->
                    <div class="sidebar-widget sidebar-categories">
                        <div class="widget-title">
                            <h3>FILTERS</h3>
                        </div>
                        <div class="widget-content">
                            <ul class="accordion-box">
                                <li class="accordion block active-block">
                                    <div class="acc-btn active">
                                        <h4><span>+</span> Type</h4>
                                    </div>
                                    <div class="acc-content current">
                                        <div class="content">
                                            <p>
                                                <?= $this->Form->select('case_type', [
                                                    'Oscer' => '  Oscer',
                                                    'Long' => '  Long',
                                                    'Medium' => '  Medium',
                                                    'Short' => '  Short',
                                                    'General' => '  General',
                                                ], [
                                                    'class' => 'select select_mod-a jelect',
                                                    'default' => $this->request->getQuery('case_type'),
                                                    'empty' => 'Choose Case Type',
                                                    'multiple' => 'checkbox',
                                                ]); ?>
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block active-block">
                                    <div class="acc-btn">
                                        <h4><span>+</span>Contributor</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p>
                                                <?= $this->Form->select('contributor', [
                                                    'Trainee' => '  Trainee',
                                                    'Consultant' => '  Consultant',
                                                    'Library' => '  Library',
                                                ], [
                                                    'class' => 'select select_mod-a jelect',
                                                    'default' => $this->request->getQuery('contributor'),
                                                    'empty' => 'Choose Contributor',
                                                    'multiple' => 'checkbox',
                                                ]); ?>
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block active-block">
                                    <div class="acc-btn">
                                        <h4><span>+</span>Rating</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p> <?= $this->Form->select('rating', [
                                                    '1' => '  1',
                                                    '2' => '  2',
                                                    '3' => '  3',
                                                    '4' => '  4',
                                                    '5' => '  5',
                                                ], [
                                                    'class' => 'form-select',
                                                    'default' => $this->request->getQuery('rating'),
                                                    'empty' => 'Choose Rating',
                                                    'multiple' => 'checkbox',
                                                    'id' => 'form-select',
                                                ]); ?>
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block active-block">
                                    <div class="acc-btn">
                                        <h4><span>+</span>Specialty</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p>
                                                <?= $this->Form->select('specialty', [
                                                    'ABDOMINAL' => '  ABDOMINAL',
                                                    'CARDIOTHORACIC' => '  CARDIOTHORACIC',
                                                    'NEURO' => '  NEURO',
                                                    'HEAD AND NECK' => '  HEAD AND NECK',
                                                    'MSK' => '  MSK',
                                                    'BREAST' => '  BREAST',
                                                    'GYN' => '  GYN',
                                                    'O+G' => '  O+G',
                                                    'PEADS' => '  PEADS',
                                                    'VASCULAR' => '  VASCULAR',
                                                    'INTERVENTION' => '  INTERVENTION',
                                                ], [
                                                    'class' => 'form-select',
                                                    'default' => $this->request->getQuery('specialty'),
                                                    'empty' => 'Choose Specialty',
                                                    'multiple' => 'checkbox',
                                                ]); ?>
                                            </p>
                                        </div>
                                    </div>
                                </li>
                                <li class="accordion block active-block">
                                    <div class="acc-btn">
                                        <h4><span>+</span>Imaging</h4>
                                    </div>
                                    <div class="acc-content">
                                        <div class="content">
                                            <p>
                                                <?= $this->Form->select('imaging', [
                                                    'X-ray' => '  X-ray',
                                                    'Ultrasound' => '  Ultrasound',
                                                    'CT' => '  CT',
                                                    'MRI' => '  MRI',
                                                    'Nuclear Medicine' => '  Nuclear Medicine',
                                                    'Fluoroscopy' => '  Fluoroscopy',
                                                    'Mammography' => '  Mammography',
                                                    'Other' => '  Other',
                                                ], [
                                                    'class' => 'form-select',
                                                    'default' => $this->request->getQuery('imaging'),
                                                    'empty' => 'Select Imaging',
                                                    'multiple' => 'checkbox',
                                                ]) ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Filter variables End -->

                    <div class="sidebar-widget sidebar-tags">
                        <div class="widget-title">
                            <div class="widget-content" style="display: flex; justify-content: space-around; align-items: center;">
                                <?= $this->Form->button(__('Apply Filter'), ['class' => 'theme-btn style-one', 'style' => 'margin-right: 10px;']) ?>
                                <?= $this->Form->end() ?>
                                <a href="<?= $this->Url->build('/') ?>"><button class="theme-btn style-two" style="flex: 1;">Reset Filter</button></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div id="moncases-grid" class="col-lg-9 col-md-12 col-sm-12 content-side">
                <div class="blog-grid-content">
                    <div class="row clearfix">
                        <?php if ($moncases->count() > 0) : ?>
                            <?php foreach ($moncases as $index => $moncase) : ?>
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="project-block-one mb-100 wow fadeInUp" data-wow-delay="00ms" data-wow-duration="1500ms">
                                        <div class="inner-box" style="text-align: center;">
                                            <div class="image-holder">
                                                <figure class="image-box" style="height: fit-content;">
                                                    <a href="<?= $this->Url->build(['controller' => 'moncases', 'action' => 'viewNotadmin', $moncase->id])?>">
                                                        <img src="<?= $this->Url->image($moncase -> image_url, ['alt' => 'photo']) ?>" style="object-fit: fill; width: 390px; height: 340px;">
                                                    </a>
                                                </figure>
                                            </div>
                                            <div class="lower-content" style="height: fit-content;">
                                                    <span class="designation"><?= h($moncase->case_type) ?>&nbsp;|&nbsp;
                                                        <?= h($moncase->author) ?>&nbsp;|&nbsp;
                                                        <?= h($moncase->date) ?>
                                                    </span>
                                                <h3><?= h($moncase->diagnosis) ?></h3>
                                                <div class="container">
                                                    <div id="textCarousel<?= $index ?>" class="carousel slide" data-ride="carousel" data-touch="true" data-interval="false">
                                                        <div class="carousel-inner">
                                                            <div class="carousel-item active">
                                                                <div class="carousel-text">
                                                                    <h5>Specialty</h5>
                                                                    <p><?= !empty($moncase->specialty) ? h($moncase->specialty) : 'N/A' ?></p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="carousel-text">
                                                                    <h5>Teaching Points</h5>
                                                                    <p><?= !empty($moncase->teaching_points) ? h($moncase->teaching_points) : 'N/A' ?></p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="carousel-text">
                                                                    <h5>Imaging</h5>
                                                                    <p><?= !empty($moncase->imaging) ? h($moncase->imaging) : 'N/A' ?></p>
                                                                </div>
                                                            </div>
                                                            <div class="carousel-item">
                                                                <div class="carousel-text">
                                                                    <h5>Rating</h5>
                                                                    <p><?= !empty($moncase->rating) ? h($moncase->rating) : 'N/A' ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <a class="carousel-control-prev" style="margin-right: 19px;" href="#textCarousel<?= $index ?>" role="button" data-slide="prev">
                                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                            <span class="sr-only">Previous</span>
                                                        </a>
                                                        <a class="carousel-control-next" href="#textCarousel<?= $index ?>" role="button" data-slide="next">
                                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                            <span class="sr-only">Next</span>
                                                        </a>
                                                    </div>
                                                    <div class="row" style="display: flex; justify-content: center; flex-wrap: nowrap;">

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <dev class="noresults">
                                <p>No results found.</p>
                            </dev>
                        <?php endif; ?>
                    </div>
                    <!-- Pagination Controls -->
                    <div class="pagination-weapper text-center">
                        <ul class="pagination clearfix">
                            <li><?= $this->Paginator->first('<<'); ?></li>
                            <li><?= $this->Paginator->prev('<') ?></li>
                            <li><?= $this->Paginator->numbers([
                                    'modulus' => 3,
                                ]) ?></li>
                            <li><?= $this->Paginator->next('>') ?></li>
                            <li><?= $this->Paginator->last('>>'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- list view-->
            <div id ="moncases-list" class="col-lg-9 col-md-12 col-sm-12 content-side" style="display: none">
                <div class="row clearfix">
                    <table class="table table-hover table-responsive wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms" style="margin-left: 18px;">
                        <thead>
                        <tr>
                            <th>Image</th>
                            <th>Accession No.</th>
                            <th>Type</th>
                            <th>Diagnosis</th>
                            <th>Imaging</th>
                            <th>Contributor</th>
                            <th>Date</th>
                            <th>Rating</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php if ($moncases->count() > 0) : ?>
                            <?php foreach ($moncases as $moncase) : ?>
                                <tr>
                                    <td>
                                        <img src="<?= $this->Url->image($moncase -> image_url, ['alt'=>'photo']) ?>" style=" height: 142px; max-width: fit-content;">
                                    </td>
                                    <td style="text-align: center;"> <a href="<?= $this->Url->build(['controller' => 'moncases', 'action' => 'viewNotadmin', $moncase->id])?>"> <?= h($moncase->accession_no)?></a></td>
                                    <td><?= h($moncase->case_type) ?></td>
                                    <td><?= h($moncase->diagnosis) ?></td>
                                    <td><?= !empty($moncase->imaging) ? h($moncase->imaging) : 'N/A' ?></td>
                                    <td><?= h($moncase->contributor) ?></td>
                                    <td><?= h($moncase->date) ?></td>
                                    <td><?= !empty($moncase->rating) ? h($moncase->rating) : 'N/A' ?></td>

                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <dev class="noresults">
                                <p>No results found.</p>
                            </dev>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Controls -->
                <div class="pagination-weapper text-center">
                    <ul class="pagination clearfix">
                        <li><?= $this->Paginator->first('<<'); ?></li>
                        <li><?= $this->Paginator->prev('<') ?></li>
                        <li><?= $this->Paginator->numbers([
                                'modulus' => 3,
                            ]) ?></li>
                        <li><?= $this->Paginator->next('>') ?></li>
                        <li><?= $this->Paginator->last('>>'); ?></li>
                    </ul>
                </div>
            </div>

            <!-- sidebar of filters and search bar -->
        </div>
    </div>
</section>
<!-- blog-grid end -->

